package company;

public class Employee {
	public String name;
}





