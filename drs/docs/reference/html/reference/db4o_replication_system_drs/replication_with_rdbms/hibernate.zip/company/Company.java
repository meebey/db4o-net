package company;

public class Company {
	public String name;
}

