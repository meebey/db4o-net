package f1.one_to_one;

public class Pilot {
	String name;
	Helmet helmet;
}
