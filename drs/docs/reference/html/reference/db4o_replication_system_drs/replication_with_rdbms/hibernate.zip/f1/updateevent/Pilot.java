package f1.updateevent;

import java.util.HashSet;
import java.util.Set;

public class Pilot {
	String name;
	Set cars = new HashSet();
}
