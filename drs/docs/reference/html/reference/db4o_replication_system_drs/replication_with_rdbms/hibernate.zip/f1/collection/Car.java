package f1.collection;

public class Car {
	public String brand;
	public String model;
}
