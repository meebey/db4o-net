package f1.collection.map;

import java.util.Map;

public class Pilot {
	String name;
	Map cars;
}
