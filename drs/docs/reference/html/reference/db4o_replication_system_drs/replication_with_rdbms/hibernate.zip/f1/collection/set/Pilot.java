package f1.collection.set;

import java.util.Set;

public class Pilot {
	String name;
	Set cars;
}
