package f1.singleobject;

public class Pilot {
	String name;
	int points;
}
