package company;

public class Customer {
}
