package f1.one_to_one;

public class Helmet {
	String model;
}
