package f1.collection.list;

import java.util.List;

public class Pilot {
	String name;
	List cars;
}
