package f1.collection.array;

import f1.collection.Car;

public class Pilot {
	String name;
	Car[] cars;
}
