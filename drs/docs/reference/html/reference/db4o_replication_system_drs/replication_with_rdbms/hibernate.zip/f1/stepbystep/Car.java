package f1.stepbystep;

public class Car {
	public String brand;
	public String model;

	public Car() {
	}

	public Car(String brand, String model) {
		this.brand = brand;
		this.model = model;
	}
}
