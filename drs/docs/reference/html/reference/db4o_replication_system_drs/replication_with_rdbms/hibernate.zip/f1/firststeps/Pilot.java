package f1.firststeps;

public class Pilot {
	String name;
	int points;

	public Pilot() {}
	
	public Pilot(String name, int points) {
		this.name = name;
		this.points = points;
	}
}
